/* Defines the card entity */
export interface ICard {
    cardNumber: number;
    cardName: string;
    accountBal: number;
}

